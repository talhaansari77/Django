from django.shortcuts import render
from requests.compat import quote_plus
# you got to install this package from 'pip install bs4'
from bs4 import BeautifulSoup
from . import models

# you got to install this package from 'pip install requests'
import requests

base_url = 'http://ahmedabad.craigslist.org/search/?query={}'
base_image_url = 'http://images.craigslist.org/{}_300x300.jpg'


def home(request):
    return render(request, 'base.html')


def new_search(request):
    search = request.POST.get('search')
    models.Search.objects.create(search=search)
    final_url = base_url.format(quote_plus(search))
    response = requests.get(final_url)
    data = response.text
    soup = BeautifulSoup(data, features='html.parser')
    post_listings = soup.find_all('li', {'class': 'result-row'})
        
    final_posting = []
    for post in post_listings:
        post_title = post.find(class_='result-title').text
        post_url = post.find('a').get('href').text
        if post.find(class_='result-price'):
            post_price = post.find(class_='result-price').text
        else:
            post_price = 'N/A'

        if post.find(class_='result-image').get('data-ids'):
            post_image_id = post.find(class_='result-image').get('data-ids').split(',')[0].split(':')[1]
            post_image_url = base_image_url.format(post_image_id)
        else:
            post_image_url = 'http://craigslist.org/images/peace.jpg'

        final_posting.append((post_title, post_url, post_price, post_image_url))
        
    stuff_for_frontend = {
        'search': search,
        'final_posting': final_posting,
    }
    return render(request, 'pages/new_search.html', stuff_for_frontend)

