from django.urls import path
from . import views


urlpatterns = [
    # you can use this expression 
    # '^' Start With '$' End With 
    path('', views.index, name="index"),
    path('detail/<int:post_id>', views.details, name="details")
]

