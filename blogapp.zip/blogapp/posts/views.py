from django.shortcuts import render
from django.http import HttpResponseRedirect, HttpResponse
from .models import Posts


def index(request):
    posts = Posts.objects.all().order_by("-pub_date")
    mycontext = {
        'title' : 'Latest Post',
        'posts' : posts,
    }
    return render(request, 'posts/index.html', mycontext)


def details(request, post_id):
    posts = Posts.objects.get(pk=post_id)
    mycontext = {
        'title' : posts.title,
        'body' : posts.body,
        'pub_date' : posts.pub_date,
    }
    return render(request, 'posts/details.html', mycontext)

