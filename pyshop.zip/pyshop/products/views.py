from django.shortcuts import render
from django.http import HttpResponse
from .models import Products, Offer



def index(request):
    Product = Products.objects.all()
    my_context = {
        'products' : Product,
    }
    return render(request, 'pages/index.html', my_context)


def new(request):
    return HttpResponse('This is a new Page')

