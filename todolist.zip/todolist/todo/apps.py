from django.apps import AppConfig


class TodoConfig(AppConfig):
    name = 'todo'
