from django.shortcuts import render
from django.utils import timezone
from django.http import HttpResponseRedirect, HttpResponse
from .models import ToDo



def index(request):
    my_to_do_list = ToDo.objects.all().order_by("-added_date")
    mycontext = {
        'my_to_do_list': my_to_do_list,
    }
    return render(request, 'pages/index.html', mycontext)


def add_to_do(request):
    #print(request.POST)
    current_date = timezone.now()
    mycontent = request.POST["content"]
    #print(content)
    #print(current_date)
    ToDo.objects.create(added_date=current_date, text=mycontent)
    return HttpResponseRedirect("/")


def delete_to_do(request, todo_id):
    #return HttpResponse(f"Delete todo Item :{todo_id}")
    ToDo.objects.get(id=todo_id).delete()
    return HttpResponseRedirect("/")

