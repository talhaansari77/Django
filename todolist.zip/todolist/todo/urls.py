from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('add_to_do/', views.add_to_do, name='add_to_do'),
    path('delete_to_do/<int:todo_id>/', views.delete_to_do, name='delete_to_do'),
]